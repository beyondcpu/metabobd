#[[ problem ]] && Email fujin@genomics.cn && date: 2013.03.21
#!/usr/bin/perl -w 
use strict;
use FindBin qw($Bin);
use File::Basename;
use File::Path;
use File::Copy;

die "Usage:\n$0 <Project_Name|test> <in|sample.list> <in|test.csv> <outDir> <Rscript.exe>\nFor Example:\n$0 test ./Example/samples_list.txt ./Example/test.csv ./Example \"C:/Program Files/R/R-2.15.0/bin/Rscript.exe\"\n" unless @ARGV==5;

my ($Project,$sample_list,$in_csv,$outDir,$Rscript)=@ARGV[0,1,2,3,4];

my $log="nul";
#my $log=">$outDir/log.txt";

#==================== check ====================================================
$Rscript||="\"C:/Program Files/R/R-2.15.0/bin/Rscript.exe\"";

$sample_list=~s/\\/\//g;
$in_csv=~s/\\/\//g;
$outDir=~s/\\/\//g;
$Rscript=~s/\\/\//g;

if(!-f $sample_list){print "Wrong: $sample_list, file does not exist.";exit;}
if(!-f $in_csv){print "Wrong: $in_csv, file does not exist.";exit;}
if(!-f $Rscript){print "Wrong: $Rscript, file does not exist.";exit;}

#if($sample_list=~/\s+/ && $sample_list!~/^"|"$/){$sample_list="\"$sample_list\"";}
#if($in_csv=~/\s+/ && $in_csv!~/^"|"$/){$in_csv="\"$in_csv\"";}
#if($outDir=~/\s+/ && $outDir!~/^"|"$/){$outDir="\"$outDir\"";}
if($Rscript=~/\s+/ && $Rscript!~/^"|"$/){$Rscript="\"$Rscript\"";}

mkpath(["$outDir"],0,0755) unless -d "$outDir";

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$year=$year+1900;
$mon=$mon+1;

print "start: $year-$mon-$mday $hour:$min:$sec\n";

#==================================================================================
#===================== have_QC.pl =================================================
#==================================================================================

#===================== 1 Quality_control ==========================================

my $outDir_have_QC="$outDir/Quality_control";
mkpath(["$outDir_have_QC"],0,0755) unless -d "$outDir_have_QC";

my (%hash,%sample_name,%order_index,%QC_index,%QC,%QC_mz)=();
my (@sample,@order,@st,@ed)=();
my ($order_last,$zero_cnt,$filter_freq,$st,$temp)=(1,0,0.8,1,"");

#===============================================================
open IN,"<$sample_list" or die $!;
#        Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#QC5     1       NA      NA      NA      NA      NA      NA      NA
#14      1       3       F       108     28      NA      NA      NA
while(<IN>)
{
	chomp;
	if($.==1){next;}
	my @r=split /\s+/;
	my ($Sample_Name,$Order)=@r[0,1];
	if($Order!~/\d+/){$temp=$.-2;print "Something is wrong!!!: $.:$_\n";last;}
	$sample_name{$Sample_Name}=$.-2;
	push @sample,$Sample_Name;
	push @order,$Order;
	if($Sample_Name=~/^QC/){$QC_index{$.-2}=1;}

	if($Order!=$order_last){$st.=",".($.-2);$order_last=$Order;}
	$order_index{$Order}++;
}
if($temp eq ""){$st.=",".($.-1);}else{$st.=",$temp";}
close IN;

my $max_order=(sort {$b<=>$a} keys %order_index)[0];
my $order_num=keys %order_index;
if($order_num!=$max_order){print "Wrong: $order_num!=$max_order; the order is 1,2,3,4,..., please check!\n";die;}

#===============================================================
my $out_txt="$outDir_have_QC/csv_intensity.txt";
my $QC_rsd_out="";

open OT,">$out_txt" or die $!;
open IN,"<$in_csv" or die $!;
#X,name,fold,tstat,pvalue,mzmed,mzmin,mzmax,rtmed,rtmin,rtmax,npeaks,QC_N.noQC1.5,HF_ZSL,N001,N011,isotopes,adduct,pcgroup,t.pvalue,wilcox.pvalue,t.fdr,med.ratio
#1481,M316T132,83.92679741,-6.406159015,2.56796e-07,316.082093,316.0813147,316.0830949,132.5,117.414,146.096,33,1,26,93408961.44,351321.7033,[1][M]+,[M+Na]+ 293.093,1,8.12782401825453e-06,0.00712760759414872,0.000123183143558799,0.00525270475420999
while(<IN>)
{
	chomp;
	s/\s+$//;
	if($.==1) # header
	{
		s/"//g;
		my @head=split /,/;
		my $header="";
		foreach my $i(0..$#head)
		{
			if(exists $sample_name{$head[$i]}){$hash{$sample_name{$head[$i]}}=$i;} # $sample_name{$head[$i]}: save the column order.
		}

		foreach my $i(0..$#sample)
		{
			if(exists $hash{$i}){$header.="\t$sample[$i]_$order[$i]";}
		}
		print OT "$header\n";
		next;
	}
	
	my @r=split /,/;
	my $str_out="$r[1]";
	$zero_cnt=0;
	foreach my $i(0..$#sample)
	{
		next unless exists $hash{$i};
		$str_out.="\t$r[$hash{$i}]";
		if($r[$hash{$i}]==0){$zero_cnt++;}
	}
	next unless $zero_cnt/($#sample+1)<=$filter_freq; # $filter_freq=0.8
	print OT "$str_out\n";
	
	foreach my $i(0..$#sample)
	{
		next unless exists $hash{$i};
		if(exists $QC_index{$i})
		{
			push @{$QC{$order[$i]}{$.-2}},$r[$hash{$i}]; # QC sample for RSD
			push @{$QC{"all"}{$.-2}},$r[$hash{$i}]; # QC sample for RSD
		}
	}
	$QC_mz{$.-2}=$r[1];
}
close IN;
close OT;

#==================== RSD ===============================================
foreach my $order(sort keys %QC)
{
	my $rsd_file="$outDir_have_QC/rsd.$order.txt";
	open OT,">$rsd_file" or die $!;
	print OT "mzmed\tRSD\n";
	foreach my $i(sort {$a<=>$b} keys %{$QC{$order}})
	{
		my $rsd=&RSD(\@{$QC{$order}{$i}});
		print OT "$QC_mz{$i}\t$rsd\n";
	}
	close OT;
}

#==================== loess.R =================================================
my $out_loess_txt="$outDir_have_QC/loess";
my $pdf="$outDir_have_QC/loess";

my $R_code=<<qq;
#!/opt/blc/genome/biosoft/R/bin/R

x<-read.table("$out_txt",head=T)
x<-as.matrix(x)
xb<-x
y<-seq(1,length(colnames(x)),1)
cn<-colnames(x)

for(j in 1:$max_order)
{
	group_j<-grep(paste("^\\\\w+_",j,"\$",sep=""),cn)
	st_QC<-grep("^QC",cn[group_j[1]])
	ed_QC<-grep("^QC",cn[group_j[length(group_j)]])
	if(length(st_QC)==0)
	{
		if(j==1){cat("Wrong: the first sample must be QC_j; please check ......\n");q();}
		st_QC_temp<-grep("^QC",cn[1:group_j[1]-1])
		if(length(st_QC_temp)==0){cat("Wrong: grep(paste(\'^QC\',cn[group_j[1]-1]);\n");q();}
		st_QC<-st_QC_temp[length(st_QC_temp)]
		group_j<-c(st_QC,group_j)
	}

	if(length(ed_QC)==0)
	{
		cat("Wrong: the last one sample must be QC_j; please check ......\n");q();
	}

	qcid<-grep("^QC\\\\w*_\\\\d+\$",cn[group_j])
	x_tmp<-x[,group_j]
	xb_tmp<-xb[,group_j]
	y_tmp<-seq(1,length(colnames(x_tmp)),1)

	for(i in 1:dim(x_tmp)[1])
	{
		loe<-loess(x_tmp[i,qcid]~qcid)
		yf<-predict(loe,y_tmp)
		x_tmp[i,]<-x_tmp[i,]/yf
	}
	write.table("mzmed",paste("$out_loess_txt.",j,".txt",sep=""),sep="",quote=F,eol="\\t",col.names=FALSE,row.names=FALSE)
	write.table(x_tmp,paste("$out_loess_txt.",j,".txt",sep=""),sep="\\t",quote=F,append=TRUE)
}

#============ all sample loess =========================================
qcid<-grep("^QC",cn)
for(i in 1:dim(x)[1])
{
	loe<-loess(x[i,qcid]~qcid)
	yf<-predict(loe,y)
	x[i,]<-x[i,]/yf
}
write.table("mzmed","$out_loess_txt.all.txt",sep="",quote=F,eol="\\t",col.names=FALSE,row.names=FALSE)
write.table(x,"$out_loess_txt.all.txt",sep="\\t",quote=F,append=TRUE)

qq

open OT,"|$Rscript - 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

#====================== loess RSD =======================================
my @group_order1=sort keys %QC;

foreach my $order(@group_order1)
{
	my $loess_rsd_file="$outDir_have_QC/loess.rsd.$order.txt";
	my $loess_file="$outDir_have_QC/loess.$order.txt";
	if(!-s $loess_file){print "Wrong: $loess_file!!!\n";next;}

	my @QC_col_index=();

	open OT,">$loess_rsd_file" or die $!;
	open IN,"<$loess_file" or die $!;
	#mzmed   QC5_1   A1_1    A2_1    A3_1    A4_1
	#51.3534378721754        -0.103635309430242      -0.132567590542483      -0.111550319987232      -0.252500354637989      -0.538046953224088
	while(<IN>)
	{
		chomp;
		my @r=split /\t/;
		if($.==1)
		{
			print OT "mzmed\tRSD\n";
			foreach my $i(1..$#r){if($r[$i]=~/^QC/){push @QC_col_index,$i;}}
			next;
		}
		if(scalar(@QC_col_index)==0){print "Wrong: QC_sample_number==0; $loess_file;\n";die;}
		my @s=();
		foreach my $i(0..$#QC_col_index){push @s,$r[$QC_col_index[$i]];}
		foreach my $i(0..$#s){if($s[$i] eq "NA"){$s[$i]=0;}}
		my $rsd=&RSD(\@s);
		print OT "$r[0]\t$rsd\n";
	}
	close IN;
	close OT;

	#==================== R ==============================
	my $rsd_file="$outDir_have_QC/rsd.$order.txt";
	my $stat_file="$outDir_have_QC/RSD.$order.stat";
	my $prefix="group_$order";
	my $pdf="$outDir_have_QC/RSD.$order.pdf";
	my $jpg="$outDir_have_QC/RSD.$order.jpg";

my $R_code=<<qq;
file<-commandArgs(TRUE)
if(length(file)!=1){cat("Usage:\\nRscript xxx.R <picture_type|[pdf|jpg]>\\n");quit()}

if(file[1]=="pdf"){pdf("$pdf")}else{jpeg("$jpg",width=600,height=480,units="px")}
par(mfrow=c(2,2))
#=====================================================
rt1<-read.table("$rsd_file",head=T)
rt1<-as.matrix(rt1)
A<-as.vector(rt1[,2])
for(i in 1:length(A)){if(A[i]>200){A[i]=200;}}
x_st1<-as.integer(min(A))
x_ed1<-as.integer(max(A))

hist(A,main="$prefix RSD Frequency Distribution",sub="before Loess",xlab="rsd value(%)",ylab="Number",xlim=c(x_st1,x_ed1),seq(x_st1,x_ed1,by=1),freq=FALSE)
lines(density(A),col="red",lwd=2)
rug(A)
plot(ecdf(A),do.points=FALSE,verticals=TRUE)

#=====================================================
rt2<-read.table("$loess_rsd_file",head=T)
rt2<-as.matrix(rt2)
B<-as.vector(rt2[,2])
for(i in 1:length(B)){if(B[i]>200){B[i]=200;}}
x_st2<-as.integer(min(B))
x_ed2<-as.integer(max(B))

hist(B,main="$prefix RSD Frequency Distribution",sub="after Loess",xlab="rsd value(%)",ylab="Number",xlim=c(x_st2,x_ed2),seq(x_st2,x_ed2,by=1),freq=FALSE)
lines(density(B),col="red",lwd=2)
rug(B)
plot(ecdf(B),do.points=FALSE,verticals=TRUE)

dev.off()
 
#=====================================================
max_ed<-max(x_ed1,x_ed2)
r<-hist(A,breaks=c(0,30,60,90,120,max_ed),plot=FALSE)
rb<-hist(B,breaks=c(0,30,60,90,120,max_ed),plot=FALSE)
tmp<-paste("120-",max_ed,sep="")
interval<-c("0-30","30-60","60-90","90-120",tmp)
m<-cbind(interval,r\$counts,rb\$counts)

write.table("rsd%\\tBefore loess\\tAfter loess","$stat_file",quote=F,col.names=FALSE,row.names=FALSE)
write.table(m,"$stat_file",sep="\\t",quote=F,col.names=FALSE,row.names=FALSE,append=TRUE)

qq

	open OT,"|$Rscript - pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
	open OT,"|$Rscript - jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

	if((-f "$loess_rsd_file") && ($order ne "all")){unlink("$loess_rsd_file");}
	if((-f "$loess_file") && ($order ne "all")){unlink("$loess_file");}
	if(-f "$rsd_file"){unlink("$rsd_file");}
}

#====================== RSD =============================================
#http://baike.baidu.com/view/787168.htm
#(RSD:relative standard deviation)
sub RSD
{
	my $x=$_[0];
	my @X=@{$x};

	if($#X<5){print "Sample numbers need more than 5; \$#X=$#X;\n";die;}
	
	my ($sum1,$sum2,$mean,$SD,$RSD)=(0,0,0,0,0);
	foreach my $i(0..$#X){$sum1+=$X[$i];}
	$mean=$sum1/($#X+1);
	if($mean==0){print "Wrong: mean=$mean;\n";return 0;}
	foreach my $i(0..$#X){$sum2+=($X[$i]-$mean)**2;}
	$SD=($sum2/$#X)**0.5;
	$RSD=100*$SD/$mean;
	if($RSD<0){$RSD=0-$RSD;}

	return $RSD;
}
#====================== PCA ==============================================
my %RSD_0_30_mz=();

open IN,"<$outDir_have_QC/loess.rsd.all.txt" or die $!;
#mzmed   RSD
#51.3534378721754        55.7974321793767
#51.42690345282  46.0978032649179
while(<IN>)
{
	chomp;
	if($.==1){next;}
	my @r=split /\s+/;
	if($r[1]>=0 && $r[1]<=30){$RSD_0_30_mz{$r[0]}=$r[1];}
}
close IN;
unlink("$outDir_have_QC/loess.rsd.all.txt");

#================== intensity_RSD_0_30.txt =========================
open OT,">$outDir_have_QC/before_LSC.txt" or die $!;
open IN,"<$out_txt" or die $!;
#        QC5_1   A1_1    A2_1    A3_1    A4_1
#51.3534378721754        4186.08801596984        4520.6571401697 3108.7304534552 5478.36053984022        8385.94853440371
while(<IN>)
{
	chomp;
	my @r=split /\t/;
	if($.==1){print OT "$_\n";next;}
	if(exists $RSD_0_30_mz{$r[0]}){print OT "$_\n";}
}
close IN;
close OT;

unlink("$out_txt");

#================== RSD_0_30.csv ===============================
my %csv_tmp=();
my $out_csv="$outDir_have_QC/$Project\_RSD_0_30.csv";

open OT,">$out_csv" or die $!;
open IN,"<$in_csv" or die $!;
#X,name,fold,tstat,pvalue,mzmed,mzmin,mzmax,rtmed,rtmin,rtmax,npeaks,QC_N.noQC1.5,HF_ZSL,N001,N011,isotopes,adduct,pcgroup,t.pvalue,wilcox.pvalue,t.fdr,med.ratio
#1481,M316T132,83.92679741,-6.406159015,2.56796e-07,316.082093,316.0813147,316.0830949,132.5,117.414,146.096,33,1,26,93408961.44,351321.7033,[1][M]+,[M+Na]+ 293.093,1,8.12782401825453e-06,0.00712760759414872,0.000123183143558799,0.00525270475420999
while(<IN>)
{
	chomp;
	s/\s+$//;
	s/"//g;
	my @r=split /,/;
	my $str_out="";
	if($.==1){@{$csv_tmp{"head"}}=(@r[0..2]);print OT "$_\n";next;}
	if(exists $RSD_0_30_mz{$r[1]}){@{$csv_tmp{$r[1]}}=(@r[0..2]);print OT "$_\n";}
}
close IN;
close OT;

#===================== 2 Metabolic_profiling ==========================================
#================== loess_all_RSD_0_30.txt ===============================
mkpath(["$outDir/Metabolic_profiling"],0,0755) unless -d "$outDir/Metabolic_profiling";

my $out_csv_loess="$outDir/Metabolic_profiling/Metabolic_profiling_LSC.csv";
my $pca_file="$outDir_have_QC/after_LSC.txt";

open CS,">$out_csv_loess" or die $!;
open OT,">$pca_file" or die $!;
open IN,"<$outDir_have_QC/loess.all.txt" or die $!;
#mzmed   QC5_1   A1_1    A2_1    A3_1    A4_1
#51.3534378721754        -0.103635309430242      -0.132567590542483      -0.111550319987232      -0.252500354637989      -0.538046953224088
while(<IN>)
{
	chomp;
	my @r=split /\t/;
	if($.==1)
	{
		s/^mzmed//;
		print OT "$_\n";
		print CS join(",",${$csv_tmp{"head"}}[0],"RSD",@{$csv_tmp{"head"}}[1..2],@r[1..$#r])."\n";
		next;
	}
	if(exists $RSD_0_30_mz{$r[0]})
	{
		print OT "$_\n";
		print CS join(",",${$csv_tmp{$r[0]}}[0],$RSD_0_30_mz{$r[0]},@{$csv_tmp{$r[0]}}[1..2],@r[1..$#r])."\n";
	}
}
close IN;
close OT;
close CS;

unlink("$outDir_have_QC/loess.all.txt");

#================== PCA plot ===============================
$R_code=<<qq;
#!/opt/blc/genome/biosoft/R/bin/Rscript
library(pls)

file<-commandArgs(TRUE)

if(length(file)!=3)
{
	cat("Usage:\\nRscript pca.R <in|after_LSC.txt> <out|PCA_score_plot_after_LSC.pdf> <picture_type|[pdf|jpg]>\\n")
	quit()
}

in_txt<-file[1]
out_pdf<-file[2]

#============= Auto_Scaling =======================================
Auto_Scaling<-function(data)
{
	A=as.matrix(data)
	B=matrix(0,length(A[,1]),length(A[1,]))
	colnames(B)=colnames(A)
	rownames(B)=rownames(A)
	for(i in 1:length(A[1,]))
	{
		m=mean(A[,i])
		s=sd(A[,i])
		B[,i]=(A[,i]-m)/s
	}
	B
}

#====================================================================
#                QC5_1                   X14_1                   CHD062_1                X9_1                    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
rt<-read.table(in_txt,header=T)
rt<-as.matrix(rt)
rt<-t(rt)

x<-Auto_Scaling(rt)
#x<-scale(as.matrix(rt),center=FALSE,scale=TRUE)
p<-prcomp(x)
l<-p\$rotation # pca_loading.txt
s<-p\$x #pca_score.txt
s<- -s

sample_name<-rownames(s)
qc_sample_name<-grep("^QC",sample_name)

#======================== PC1_PC2.pdf ===================================================
if(file[3]=="pdf"){pdf(out_pdf,w=9,h=7)}else{jpeg(out_pdf,width=600,height=480,units="px")}

x<-s[,1]
y<-s[,2]

x_st<-as.integer(mean(x)-3*sd(x)-1)
x_ed<-as.integer(mean(x)+3*sd(x)+1)

y_st<-as.integer(mean(y)-3*sd(y)-1)
y_ed<-as.integer(mean(y)+3*sd(y)+1)

color<-rep("green",length(x))
for(i in qc_sample_name){color[i]="blue";}

plot(x,y,col=color,type='p',lwd=1.5,xaxt="n",yaxt="n",xlab="",ylab="",bty="o",pch=20,cex=1,xlim=c(x_st,x_ed),ylim=c(y_st,y_ed))

abline(h=0)
abline(v=0)

text(x[qc_sample_name],y[qc_sample_name],sample_name[qc_sample_name])

xpos<-c(seq(0,x_st,by=-as.integer((x_ed-x_st)/10)),seq(0,x_ed,by=as.integer((x_ed-x_st)/10)))
ypos<-c(seq(0,y_st,by=-as.integer((y_ed-y_st)/10)),seq(0,y_ed,by=as.integer((y_ed-y_st)/10)))

axis(side=1,xpos,tcl=0.2,labels=FALSE)
axis(side=2,ypos,tcl=0.2,labels=FALSE)
mtext("PC1",side=1,line=2,at=median(xpos),cex=2)
mtext("PC2",side=2,line=2,at=median(ypos),cex=2)
mtext(xpos,side=1,las=1,at=xpos,line=0.3,cex=1.4)
mtext(ypos,side=2,las=1,at=ypos,line=0.3,cex=1.4)
legend(x=x_ed-1,y=y_ed-1,xjust=1,yjust=1,cex=1,legend=c("Samples","QC"),col=c("green","blue"),pch=20,bty="n")

dev.off()
qq

open OT,"|$Rscript - $outDir_have_QC/before_LSC.txt $outDir_have_QC/PCA_score_plot_before_LSC.pdf pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - $outDir_have_QC/after_LSC.txt $outDir_have_QC/PCA_score_plot_after_LSC.pdf pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

open OT,"|$Rscript - $outDir_have_QC/before_LSC.txt $outDir_have_QC/PCA_score_plot_before_LSC.jpg jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - $outDir_have_QC/after_LSC.txt $outDir_have_QC/PCA_score_plot_after_LSC.jpg jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

unlink("$outDir_have_QC/before_LSC.txt");

#====================== csv_intensity_plot ==============================================

$R_code=<<qq;
#!/opt/blc/genome/biosoft/R/bin/Rscript

file<-commandArgs(TRUE)

if(length(file)!=3)
{
	cat("Usage:\\nRscript intensity_plot.R <in|yunfu.csv> <out|intensity_plot.pdf> <picture_type|[pdf|jpg]>\\nFor Example:\\nRscript intensity_plot.R /ifs5/ST_METABO/USER/fujin/QC/yunfu/xcms/yunfu.csv /ifs5/ST_METABO/USER/fujin/QC/yunfu/xcms/intensity_plot/intensity_plot.pdf pdf\\n\\n")
	quit()
}

in_csv<-file[1]
out_pdf<-file[2]

if(file[3]=="pdf"){pdf(out_pdf,w=9,h=7)}else{jpeg(out_pdf,width=600,height=480,units="px")}
rt<-read.table(in_csv,sep=",",head=T)
#X,name,fold,tstat,pvalue,mzmed,mzmin,mzmax,rtmed,rtmin,rtmax,npeaks,QC_N.noQC1.5,HF_ZSL,N001,N011,isotopes,adduct,pcgroup,t.pvalue,wilcox.pvalue,t.fdr,med.ratio
#1481,M316T132,83.92679741,-6.406159015,2.56796e-07,316.082093,316.0813147,316.0830949,132.5,117.414,146.096,33,1,26,93408961.44,351321.7033,[1][M]+,[M+Na]+ 293.093,1,8.12782401825453e-06,0.00712760759414872,0.000123183143558799,0.00525270475420999

QC<-grep("^QC",colnames(rt))[1]

x<-rt[,3] # rtmed
y<-rt[,2] # mzmed
z<-rt[,QC] # the first QC sample intensity

x_st<-0
x_ed<-1200 # max_Retention_Time=1200s

y_st<-50
y_ed<-1500 # max_mz=1500

z_st<-as.integer(min(z))
z_ed<-as.integer(max(z))

pos<-c(0,500000,1000000,2000000,3000000,4000000,6000000,10000000)

color<-c()
num<-0
clr<-''

for(i in 1:length(z))
{
	intensity<-as.integer(z[i])
	if(intensity>=pos[1] && intensity<pos[2])
	{
		num<-as.integer((intensity-pos[1])/((pos[2]-pos[1])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#0000",clr,sep="") # 000000 => 0000ff
	}else if(intensity<pos[3])
	{
		num<-as.integer((intensity-pos[2])/((pos[3]-pos[2])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#00",clr,"ff",sep="") # 0000ff => 00ffff
	}else if(intensity<pos[4])
	{
		num<-as.integer((intensity-pos[3])/((pos[4]-pos[3])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#00ff",clr,sep="") # 00ffff => 00ff00
	}else if(intensity<pos[5])
	{
		num<-as.integer((intensity-pos[4])/((pos[5]-pos[4])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#",clr,"ff00",sep="") # 00ff00 => ffff00
	}else if(intensity<pos[6])
	{
		num<-as.integer((intensity-pos[5])/((pos[6]-pos[5])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#ff",clr,"00",sep="") # ffff00 => ff0000
	}else if(intensity<pos[7])
	{
		num<-as.integer((intensity-pos[6])/((pos[7]-pos[6])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#ff00",clr,sep="") # ff0000 => ff00ff
	}else if(intensity<pos[8])
	{
		num<-as.integer((intensity-pos[7])/((pos[8]-pos[7])/256))
		clr<-as.raw(num) # Dec to Hex
		color[i]<-paste("#ff",clr,"ff",sep="") # ff00ff => ffffff
	}else
	{
		color[i]<-paste("#fefefe",clr,sep="")
	}
}


plot(x,y,col=color,type='p',lwd=1.5,xaxt="n",yaxt="n",xlab="",ylab="",bty="o",pch=20,cex=0.6,xlim=c(x_st,x_ed),ylim=c(y_st,y_ed))
#plot(x,y,col=color,type='p',lwd=1.5,xaxt="n",yaxt="n",xlab="",ylab="",bty="o",pch=15,cex=0.5,xlim=c(x_st,x_ed),ylim=c(y_st,y_ed))

xpos<-seq(x_st,x_ed,by=as.integer((x_ed-x_st)/20))
ypos<-seq(y_st,y_ed,by=50)

axis(side=1,xpos,tcl=0.2,labels=FALSE)
axis(side=2,ypos,tcl=0.2,labels=FALSE)
mtext("Retention Time (s)",side=1,line=2,at=median(xpos),cex=2)
mtext("m/z",side=2,line=2,at=median(ypos),cex=2)
mtext(xpos,side=1,las=1,at=xpos,line=0.3,cex=0.6)
mtext(ypos,side=2,las=1,at=ypos,line=0.3,cex=0.6)
legend(x=x_ed-8,y=y_ed-2,xjust=1,yjust=1,cex=0.8,legend=paste("Sample:",colnames(rt)[QC],"(intensity/10000)",sep=""),bty="n")

tmp<-as.integer(256/4)
x_st1<-x_ed-70
x_ed1<-x_ed-10
y_st1<-y_ed-550
y_ed1<-y_ed-550+(7*tmp)
pos<-pos/10000
da<-5

for(i in 1:tmp) # hua tu li
{
	num<-(i-1)*4
	clr<-as.raw(num) # Dec to Hex
	num2<-(tmp-i+1)*4-1
	clr2<-as.raw(num2) # Dec to Hex

	# 000000 => 0000ff
	y_temp<-y_st1+i-1+tmp*0
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#0000",clr,sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[1],cex=0.7,adj=c(0,0.5));}

	# 0000ff => 00ffff
	y_temp<-y_st1+i-1+tmp*1
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#00",clr,"ff",sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[2],cex=0.7,adj=c(0,0.5));}

	# 00ffff => 00ff00
	y_temp<-y_st1+i-1+tmp*2
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#00ff",clr2,sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[3],cex=0.7,adj=c(0,0.5));}

	# 00ff00 => ffff00
	y_temp<-y_st1+i-1+tmp*3
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#",clr,"ff00",sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[4],cex=0.7,adj=c(0,0.5));}

	# ffff00 => ff0000
	y_temp<-y_st1+i-1+tmp*4
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#ff",clr2,"00",sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[5],cex=0.7,adj=c(0,0.5));}

	# ff0000 => ff00ff
	y_temp<-y_st1+i-1+tmp*5
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#ff00",clr,sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[6],cex=0.7,adj=c(0,0.5));}

	# ff00ff => ffffff
	y_temp<-y_st1+i-1+tmp*6
	lines(c(x_st1,x_ed1),c(y_temp,y_temp),col=paste("#ff",clr,"ff",sep=""))
	if(i==1){lines(c(x_ed1,x_ed1+da),c(y_temp,y_temp));text(x_ed1+da,y_temp,pos[7],cex=0.7,adj=c(0,0.5));}
}

lines(c(x_ed1,x_ed1+da),c(y_ed1,y_ed1));text(x_ed1+da,y_ed1,pos[8],cex=0.7,adj=c(0,0.5));

dev.off()

qq

open OT,"|$Rscript - $in_csv $outDir_have_QC/TIC_before_LSC.pdf pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - $out_csv $outDir_have_QC/TIC_after_LSC.pdf pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

open OT,"|$Rscript - $in_csv $outDir_have_QC/TIC_before_LSC.jpg jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - $out_csv $outDir_have_QC/TIC_after_LSC.jpg jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

unlink("$out_csv");

#==================================================================================
#===================== no_QC.pl ===================================================
#==================================================================================

my $after_LSC_txt="$outDir_have_QC/after_LSC.txt";
my $outDir_no_QC3="$outDir/Univariate_analyses_and_volcano_plot";

#===============================================================
mkpath(["$outDir_no_QC3"],0,0755) unless -d "$outDir_no_QC3";

my (%hash2,%hash3)=();
%hash=();
my $sample_list_head="";

#===============================================================
open OT,">$outDir_no_QC3/sample_list" or die $!;
open IN,"<$sample_list" or die $!;
#        Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#QC5     1       NA      NA      NA      NA      NA      NA      NA
#14      1       3       F       108     28      NA      NA      NA
while(<IN>)
{
	chomp;
	if($.==1){s/^[^\t]+\s+/\t/;print OT "$_\n";$sample_list_head=$_;next;}
	my @r=split /\t/;
	my ($Sample_Name,$batch,$group)=@r[0,1,2];
	if($Sample_Name=~/^QC/){next;}
	if($batch!~/^\d+$/){next;}
	if($group!~/^\d+$/){next;}
	$Sample_Name.="_$batch";
	$hash{$Sample_Name}=$group;
	$hash2{$Sample_Name}=$_;
	
	$r[0]=$Sample_Name;
	if(@r>3){foreach my $i(3..$#r){if($r[$i] eq "NA"){$r[$i]=0;}}}
	print OT join("\t",@r[0..$#r])."\n";
}
close IN;
close OT;

#===============================================================
my @index=();
my $head1="";

open ST,">$outDir_no_QC3/sample_list_sort" or die $!;print ST "$sample_list_head\n";
open OT,">$outDir_no_QC3/after_LSC_no_QC.txt" or die $!;
open IN,"<$after_LSC_txt" or die $!;
#        QC5_1   X14_1   CHD062_1        X9_1    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
while(<IN>)
{
	chomp;
	my @r=split /\t/;
	if($.==1)
	{
		foreach my $i(1..$#r)
		{
			$r[$i]=~s/^X(\d+)/$1/;
			if(exists $hash{$r[$i]})
			{
				push @index,$i;
				$head1.="\t$r[$i]";
				
				my @s=split /\t/,$hash2{$r[$i]};
				$s[0]="$s[0]_$s[1]";
				print ST join("\t",@s)."\n";
			}
		}
		print OT "$head1\n";
		next;
	}

	my $str_out="$r[0]";
	foreach my $j(0..$#index){$str_out.="\t$r[$index[$j]]";}
	print OT "$str_out\n";
}
close IN;
close OT;
close ST;

unlink("$after_LSC_txt");

#================== 3 Univariate_analyses_and_volcano_plot (FDR) =============================================
#=================== after_LSC_no_QC_pca_score.txt ============================================

my $outDir_no_QC4="$outDir/Multivariate_statistical_analyses";
mkpath(["$outDir_no_QC4"],0,0755) unless -d "$outDir_no_QC4";
mkpath(["$outDir_no_QC4/PCA"],0,0755) unless -d "$outDir_no_QC4/PCA";

my $after_LSC_no_QC_pca_score_txt="$outDir_no_QC3/after_LSC_no_QC_pca_score.txt";

$R_code=<<qq;
#!/opt/blc/genome/biosoft/R/bin/Rscript
library(pls)

#============= Auto_Scaling =======================================
Auto_Scaling<-function(data)
{
	A=as.matrix(data)
	B=matrix(0,length(A[,1]),length(A[1,]))
	colnames(B)=colnames(A)
	rownames(B)=rownames(A)
	for(i in 1:length(A[1,]))
	{
		m=mean(A[,i])
		s=sd(A[,i])
		B[,i]=(A[,i]-m)/s
	}
	B
}

#====================================================================
in_txt<-"$outDir_no_QC3/after_LSC_no_QC.txt"
out_score_txt<-"$after_LSC_no_QC_pca_score_txt"

#====================================================================
#                QC5_1                   X14_1                   CHD062_1                X9_1                    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
rt<-read.table(in_txt,header=T)
rt<-as.matrix(rt)
rt<-t(rt)

x<-Auto_Scaling(rt)
p<-prcomp(x)
s<-p\$x #pca_score.txt
s<- -s

R2X<-explvar(p)

Importance_of_components<-summary(p)
Cumulative_Proportion<-Importance_of_components\$importance[3,1:2] # We need "Cumulative Proportion" => "PC1 PC2"

write.table("",out_score_txt,sep="",quote=F,eol="\\t",col.names=FALSE,row.names=FALSE)
write.table(s,out_score_txt,sep="\\t",quote=F,append=TRUE)

write.table("","$outDir_no_QC4/PCA/R2X_stat.txt",sep="",quote=F,eol="\\t",col.names=FALSE,row.names=FALSE)
write.table(R2X,"$outDir_no_QC4/PCA/R2X_stat.txt",sep="\\t",quote=F,append=TRUE)

qq

open OT,"|$Rscript - 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

#===============================================================
my %Group=();
my $head2="";

open IN,"<$after_LSC_no_QC_pca_score_txt" or die $!;
#        PC1     PC2     PC3     PC4     PC5
#QC5_1   -3.68922844254254       1.17293490728455        -1.03717477792938       0.456753939739932       -0.900502475357237
while(<IN>)
{
	chomp;
	if($.==1){$head2=$_;}
	my @r=split /\s+/;
	if($r[0]=~/^QC/){next;}
	$r[0]=~s/^X(\d+)/$1/;
	if(exists $hash{$r[0]})
	{
		push @{$Group{$hash{$r[0]}}},$_;
	}
}
close IN;

unlink("$after_LSC_no_QC_pca_score_txt") if -f "$after_LSC_no_QC_pca_score_txt";

#======================== 4 Multivariate_statistical_analyses =======================================
#======================== 4.1 PCA =======================================
my ($str1,$str2,$str3)=("","","");

open OT,">$outDir_no_QC4/PCA/pca_score.txt" or die $!;
print OT "$head2\n";
foreach my $i(sort {$a<=>$b} keys %Group)
{
	foreach my $j(0..$#{$Group{$i}})
	{
		print OT "$Group{$i}[$j]\n";
	}
	my $num=$#{$Group{$i}}+1;
	$str1.="\"group$i\",";
	$str2.="$num,";
	if($i%3==1)
	{
		$str3.="\"#".sprintf("%X",255-($i-1)*30)."0000\",";
	}elsif($i%3==2)
	{
		$str3.="\"#00".sprintf("%X",255-($i-2)*30)."00\",";
	}else
	{
		$str3.="\"#0000".sprintf("%X",255-($i-3)*30)."\",";
	}
}
close OT;
$str1=~s/,$//;
$str2=~s/,$//;
$str3=~s/,$//;

#======================== 4.1 PCA (plot) =======================================
$R_code=<<qq;
library(ade4)
library(car)

file<-commandArgs(TRUE)
if(length(file)!=1){cat("Usage:\\nRscript xxx.R <picture_type|[pdf|jpg]>\\n");quit()}

rt<-read.table("$outDir_no_QC4/PCA/pca_score.txt",head=T)

if(file[1]=="pdf"){pdf("$outDir_no_QC4/PCA/pca_score_plot.pdf",w=9,h=8)}else{jpeg("$outDir_no_QC4/PCA/pca_score_plot.jpg",width=600,height=480,units="px")}

#=================================================================
group<-rep(c($str1),times=c($str2))
group<-as.factor(group)

clors<-c($str3)

max_pc1<-1.3*(max(abs(rt[,1])))
max_pc2<-1.3*(max(abs(rt[,2])))
lim<-c()
if(max_pc1 > max_pc2){lim<-c(-max_pc1,max_pc1)}else{lim<-c(-max_pc2,max_pc2)}

s.class(rt[,1:2],group,grid=F,pixmap=T,cpoint=1,col=clors,xlim=lim,ylim=lim)
text(rt[,1:2],labels=rownames(rt[,1:2]),cex=0.4)

dataEllipse(rt[,1],rt[,2],levels=c(0.95),add=T,col="gray",lwd=1.4,plot.points=FALSE,center.cex=0.2)

dev.off()
qq

open OT,"|$Rscript - pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

#================== 3 Univariate_analyses_and_volcano_plot (FDR) =============================================
$R_code=<<qq;
library(qvalue)

file<-commandArgs(TRUE)
if(length(file)!=1){cat("Usage:\\nRscript xxx.R <picture_type|[pdf|jpg]>\\n");quit()}

#=================== volcano =========================================
volcano<-function(id,ratio,p,alpha=0.05,upper.lim=1.2,lower.lim=0.8,pch=20,xlab=expression(paste(log[2]," (fold change)")),ylab=expression(paste("-",log[10]," Qvalue")),main="Qvalue versus fold-change",sub="(Variables in Red are significant (Qvalue<0.05) and showed Fold Changes >1.2 or <0.8)",col=c("darkgrey","darkblue","red"),...)
{
	sig=(ratio >= upper.lim) | (ratio <= lower.lim)
	plot(log2(ratio),-log10(p),xlab=xlab,ylab=ylab,main=main,sub=sub,col="white",...)
	points(log2(ratio)[p>alpha],-log10(p)[p>alpha],pch=pch,col=col[1],...)
	points(log2(ratio)[!sig & (p <= alpha)],-log10(p)[!sig & (p <= alpha)],pch=pch,col=col[2],...)
	points(log2(ratio)[sig & (p <= alpha)],-log10(p)[sig & (p <= alpha)],pch=pch,col=col[3],...)
	abline(h=-log10(alpha),col="gray",lty=3)
	abline(v=log2(upper.lim),col="gray",lty=3)
	abline(v=log2(lower.lim),col="gray",lty=3)
	text(log2(ratio)[sig & (p <= alpha)],-log10(p)[sig & (p <= alpha)],id[sig & (p <= alpha)],cex=0.2)
#	cbind(id[sig & (p <= alpha)],ratio[sig & (p <= alpha)],p[sig & (p <= alpha)])
	data.frame(ratio[sig & (p <= alpha)],p[sig & (p <= alpha)])
}

#====================================================================
#                QC5_1                   X14_1                   CHD062_1                X9_1                    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
rt<-read.table("$outDir_no_QC3/after_LSC_no_QC.txt",head=T)
rt<-as.matrix(rt)
rt<-rt[rowSums(rt)!=0,]
num<-nrow(rt)

#====================================================================
#          Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#14_1      1       3       1       108     28      0       0       0
#CHD062_1  1       2       0       36      118     27      16      0.23
rt2<-read.table("$outDir_no_QC3/sample_list",head=T)
group<-as.numeric(rt2[,2])

Group<-unique(sort(group))

for(i in 1:(length(Group)-1))
{
	for(j in (i+1):length(Group))
	{
		dir<-paste("$outDir_no_QC3/",i,"_",j,sep="")
		if(!file_test("-d",dir)){dir.create(dir)}
		
		#============= wilcox.test/t.test ============================================
		res1<-matrix(0,nrow=num,ncol=5)
		res2<-matrix(0,nrow=num,ncol=5)
		
		rownames(res1)<-rownames(rt)
		rownames(res2)<-rownames(rt)
		
		for(k in 1:num)
		{
			line<-as.numeric(rt[k,])
			r<-rank(line)
			
			res1[k,1]<-wilcox.test(line[group==i],line[group==j])\$p.value
			res1[k,2]<-mean(r[group==i])
			res1[k,3]<-mean(r[group==j])
			res1[k,4]<-res1[k,3]/res1[k,2]
			
			res2[k,1]<-t.test(line[group==i],line[group==j])\$p.value
			res2[k,2]<-mean(r[group==i])
			res2[k,3]<-mean(r[group==j])
			res2[k,4]<-res1[k,3]/res1[k,2]
		}

		#============== FDR(wilcox.test) ============================================================
		qv<-qvalue(res1[,1],lambda=seq(0.60,0.90,0.05))
		len<-length(res1[,1])
		nt<-round(len*(1-qv\$pi0))
		alpha<-seq(0.00,1.00,0.05)
		po<-alpha
		fdr<-alpha
		for(k in 1:length(alpha))
		{
			pp<-alpha[k]
			if(k==1){pp<-sort(qv\$pvalues)[1]}
			m.len<-length(qv\$qvalues[qv\$pvalues<=pp])
			fdr[k]<-sort(qv\$qvalues[qv\$pvalues<=pp])[m.len] # fdr
			po[k]<-round(m.len*(1-fdr[k]))/nt # power
			if(po[k]>1){po[k]<-1}
		}
		res1[,5]<-qv\$qvalues
		write.table(res1,paste(dir,"/wilcox.test.txt",sep=""),sep="\\t",quote=F,col.names=F)

		if(file[1]=="pdf"){pdf(paste(dir,"/qvalue_wilcox_test_fdr.pdf",sep=""),w=8,h=8)}else{jpeg(paste(dir,"/qvalue_wilcox_test_fdr.jpg",sep=""),width=600,height=480,units="px")}
		hist(res1[,1],probability=T,xlab="P-value of Stage I",breaks=20,main="") 
		points(alpha,po*5,cex=0.5,col='blue',pch=24)
		lines(alpha,po*5,col='blue',lty=2)
		points(alpha,fdr*5,cex=0.5,col='red',pch=24)
		lines(alpha,fdr*5,col='red',lty=2)
		axis(4,seq(0,5,1),labels=seq(0,1,0.2))
		legend(x=alpha[length(alpha)-1],y=6,xjust=1,yjust=1,cex=1,legend=c("Estimated Power","Estimated FDR"),col=c("blue","red"),pch=24,bty="n")
		dev.off()

		if(file[1]=="pdf"){pdf(paste(dir,"/qvalue_wilcox_test_volcano.pdf",sep=""),w=8,h=8)}else{jpeg(paste(dir,"/qvalue_wilcox_test_volcano.jpg",sep=""),width=600,height=480,units="px")}
		id=rownames(res1)
		ratio=res1[,4]
		p=res1[,5]
		output=volcano(id,ratio,p)
		write.table(rownames(output),paste(dir,"/volcano_result_wilcox.txt",sep=""),quote=F,col.names=FALSE,row.names=FALSE)
		dev.off()
		
		#============== FDR(t.test) ===================================================================
		qv<-qvalue(res2[,1],lambda=seq(0.60,0.90,0.05))
		len<-length(res2[,1])
		alpha<-seq(0.00,1.00,0.05)
		nt<-round(len*(1-qv\$pi0))
		po<-alpha
		fdr<-alpha
		for(k in 1:length(alpha))
		{
			pp<-alpha[k]
			if(k==1){pp<-sort(qv\$pvalues)[1]}
			m.len<-length(qv\$qvalues[qv\$pvalues<=pp])
			fdr[k]<-sort(qv\$qvalues[qv\$pvalues<=pp])[m.len] # fdr
			po[k]<-round(m.len*(1-fdr[k]))/nt # power
			if(po[k]>1){po[k]<-1}
		}
		res2[,5]<-qv\$qvalues
		write.table(res2,paste(dir,"/t.test.txt",sep=""),sep="\\t",quote=F,col.names=F)

		if(file[1]=="pdf"){pdf(paste(dir,"/qvalue_t_test_fdr.pdf",sep=""),w=8,h=8)}else{jpeg(paste(dir,"/qvalue_t_test_fdr.jpg",sep=""),width=600,height=480,units="px")}
		hist(res2[,1],probability=T,xlab="P-value of Stage I",breaks=20,main="") 
		points(alpha,po*5,cex=0.5,col='blue',pch=24)
		lines(alpha,po*5,col='blue',lty=2)
		points(alpha,fdr*5,cex=0.5,col='red',pch=24)
		lines(alpha,fdr*5,col='red',lty=2)
		axis(4,seq(0,5,1),labels=seq(0,1,0.2))
		legend(x=alpha[length(alpha)-1],y=6,xjust=1,yjust=1,cex=1,legend=c("Estimated Power","Estimated FDR"),col=c("blue","red"),pch=24,bty="n")
		dev.off()
		
		if(file[1]=="pdf"){pdf(paste(dir,"/qvalue_t_test_volcano.pdf",sep=""),w=8,h=8)}else{jpeg(paste(dir,"/qvalue_t_test_volcano.jpg",sep=""),width=600,height=480,units="px")}
		id=rownames(res2)
		ratio=res2[,4]
		p=res2[,5]
		output=volcano(id,ratio,p)
		write.table(rownames(output),paste(dir,"/volcano_result_ttest.txt",sep=""),quote=F,col.names=FALSE,row.names=FALSE)
		dev.off()
	}
}
qq

open OT,"|$Rscript - pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

#======================== 4 Multivariate_statistical_analyses =======================================
#======================== 4.2 PLSDA =======================================
mkpath(["$outDir_no_QC4/PLSDA"],0,0755) unless -d "$outDir_no_QC4/PLSDA";

$R_code=<<qq;
library(pls)
library(ade4)
library(car)

file<-commandArgs(TRUE)
if(length(file)!=1){cat("Usage:\\nRscript xxx.R <picture_type|[pdf|jpg]>\\n");quit()}

#============= VIP =======================================
VIP<-function(object)
{
  if(object\$method!="oscorespls"){stop("Only implemented for orthogonal scores algorithm.  Refit with \'method = \\"oscorespls\\"\'")}
  if(nrow(object\$Yloadings)>1){stop("Only implemented for single-response models")}
  
  SS<-c(object\$Yloadings)^2 * colSums(object\$scores^2)
  Wnorm2<-colSums(object\$loading.weights^2)
  SSW<-sweep(object\$loading.weights^2, 2, SS / Wnorm2, "*")
  sqrt(nrow(SSW) * apply(SSW, 1, cumsum) / cumsum(SS))
}

#============= PAR =======================================
PAR<-function(data)
{
	A=as.matrix(data)
	B=matrix(0,length(A[,1]),length(A[1,]))
	colnames(B)=colnames(A)
	rownames(B)=rownames(A)
	for(i in 1:length(A[1,]))
	{
		m=mean(A[,i])
		s=sd(A[,i])
		B[,i]=(A[,i]-m)/sqrt(s)
	}
	B
}

#============= Auto_Scaling =======================================
Auto_Scaling<-function(data)
{
	A=as.matrix(data)
	B=matrix(0,length(A[,1]),length(A[1,]))
	colnames(B)=colnames(A)
	rownames(B)=rownames(A)
	for(i in 1:length(A[1,]))
	{
		m=mean(A[,i])
		s=sd(A[,i])
		B[,i]=(A[,i]-m)/s
	}
	B
}

#============= osccalc =======================================
#OSCCALC Calculates orthogonal signal correction
# The inputs are the matrix of predictor variables (x)
# and predicted variable(s) (y), scaled as desired, and
# the number of OSC components to calculate (nocomp).
# Optional input variables are the maximum number of
# iterations used in attempting to maximize the variance
# captured by orthogonal component (iter, default = 0),
# and the tolerance on percent of x variance to consider
# in formation of the final w vector (tol, default = 99.9).
# The outputs are the OSC corrected x matrix (nx) and
# the weights (nw), loads (np) and scores(nt) that were
# used in making the correction. Once the calibration is 
# done, new (scaled) x data can be corrected by 
# newx = x - x*nw*inv(np'*nw)*np';
#
# I/O: [x,nw,np,nt] = osccalc(x,y,nocomp,iter,tol);
#
# See also: CROSSVAL
# Copyright Eigenvector Research, Inc. 1998
# Barry M. Wise, January 23, 1998
# http://www.eigenvector.com/MATLAB/PC_M_files/osccalc.m
osccalc<-function(x,y,nocomp,iter=0,tol=99.9)
{
	m<-nrow(x)
	n<-ncol(x)

	nw<-matrix(0,n,nocomp)
	np<-matrix(0,n,nocomp)
	nt<-matrix(0,m,nocomp)

	for(i in 1:nocomp)
	{
		SVD<-svd(x,1,1) # Calculate the first score vector, [u,s,v] = svds(x,1); MATLAB: x=u*s*v', u(m*1), s(1*1), v(n*1)
		
		u<-SVD\$u # u(m*m)=(146*146)
		s<-SVD\$d # s(1*n)
		v<-SVD\$v # v(n*n)=(1353*1353)

		p<-as.matrix(v[,1]) # p(n*1)
		p<-as.matrix(p*sign(sum(p)))
		told<-as.matrix(u[,1]*s[1]) # u(m*1)

		dif<-1
		k<-0
		while(dif > 1e-12)
		{
			k<-k+1
			t<-(x%*\%p)/as.numeric(t(p)%*\%p) # t(m*1), Calculate scores from loads
			tnew<-t-(y%*\%solve(t(y)%*\%y)%*\%t(y)%*\%t) # tnew(m*1), Othogonalize t to y, y(1*n)
			pnew<-t(x)%*\%tnew/as.numeric(t(tnew)%*\%tnew) # pnew(n*1), Compute a new loading
			dif<-max((svd(tnew-told))\$d)/max((svd(tnew))\$d) # Check for convergence
			told<-tnew # Assign pnew to p
			p<-pnew
			if(k>iter){dif<-0}
		}

		nc<-Matrix::rankMatrix(x) # Build PLS model relating x to t
		# [w,ssq] = pls(x,tnew,nc,0);
		D<-list(X=x,Y=tnew)
		PLSR<-plsr(Y~X,data=D,validation="CV",method ="oscorespls") # coefficients scores loadings loading.weights Yscores Yloadings projection Xmeans Ymeans fitted.values residuals Xvar Xtotvar ncomp method validation call terms model

		w<-PLSR\$loading.weights # w(n*ncomp)=(1353*130)
		R2Y<-R2(PLSR,estimate="train") # val type comps cumulative call
		ssq<-R2Y\$val
		ssq<-ssq*100 # (130*1)

		z<-length(ssq[ssq<tol]) # Include components as specified by tol on x variance   
		nc<-z+1
		w<-as.matrix(w[,nc]) # w(ncomp*1)=t(w(n*ncomp))
		w<-w/max(svd(w)\$d) # (130*1)
		t<-x%*\%w # t(m*1), Calculate new scores vector
		t<-t-(y%*\%solve(t(y)%*\%y)%*\%t(y)%*\%t) # thogonalize t to y
		p<-(t(x)%*\%t)/as.numeric((t(t)%*\%t)) # p(n*1), Compute new p
		x<-x-t%*\%t(p) # Remove orthogonal signal from x
		np[,i]<-p
		nw[,i]<-w
		nt[,i]<-t
	}
	return(list(x=x,nw=nw,np=np,nt=nt))
}

#====================================================================
#                QC5_1                   X14_1                   CHD062_1                X9_1                    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
rt1<-read.table("$outDir_no_QC3/after_LSC_no_QC.txt",head=T)
rt1<-as.matrix(rt1)
rt1<-t(rt1)

#====================================================================
#          Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#14_1      1       3       1       108     28      0       0       0
#CHD062_1  1       2       0       36      118     27      16      0.23
rt2<-read.table("$outDir_no_QC3/sample_list",head=T)
group<-as.numeric(rt2[,2])

Group<-unique(sort(group))

for(i in 1:(length(Group)-1))
{
	for(j in (i+1):length(Group))
	{
		dir<-paste("$outDir_no_QC4/PLSDA/",i,"_",j,sep="")
		if(!file_test("-d",dir)){dir.create(dir)}

		pos_i_j<-grep(paste("^",i,"\$|^",j,"\$",sep=""),group)
		y<-group[group==i | group==j]
		
		xxx<-scale(as.matrix(rt1[pos_i_j,]),center=TRUE,scale=FALSE)
		yyy<-Auto_Scaling(y)
		osc<-osccalc(xxx,yyy,nocomp=2,iter=0,tol=99.9)
		newx <- osc\$x - (osc\$x %*% osc\$nw %*% solve(t(osc\$np) %*% osc\$nw) %*% t(osc\$np)) # newx = x - x*nw*inv(np'*nw)*np';

		x<-PAR(newx)
		D<-list(X=x,Y=y)
		p<-plsr(Y~X,data=D,validation="CV",method ="oscorespls")
		s<-scores(p)
		l<-p\$projection
		vip<-VIP(p)

		corr<-cor(x,s[,1])
		splot<-cbind(p\$loadings[,1],corr)
		YROC<-predict(p)
		l<- -l
		s<- -s
		vip<-t(vip)

		write.table(l,paste(dir,"/plsda_loadings.txt",sep=""),sep="\\t",quote=F,col.names=F,row.names=F)
		write.table(s,paste(dir,"/plsda_scores.txt",sep=""),sep="\\t",quote=F,col.names=F,row.names=F)
		write.table(vip,paste(dir,"/vip.txt",sep=""),sep="\\t",quote=F,col.names=F)
		write.table(splot,paste(dir,"/S_plot.txt",sep=""),sep="\\t",quote=F,col.names=F)

		R2Y<-R2(p,estimate="train")
		R2X<-explvar(p)
		Q2X<-R2(p,estimate="CV")

		ccc<-as.matrix(R2X)
		for(k in 1:nrow(ccc)){rownames(ccc)[k]<-paste("Comp_",k,sep="")}
		colnames(ccc)<-c("R2X")

		aaa<-as.matrix(R2Y\$val)
		aaa<-as.matrix(aaa[2:nrow(aaa),1])
		rownames(aaa)<-rownames(ccc)
		colnames(aaa)<-c("R2Y\$val")
		
		bbb<-as.matrix(Q2X\$val)
		bbb<-as.matrix(bbb[2:nrow(bbb),1])
		rownames(bbb)<-rownames(ccc)
		colnames(bbb)<-c("Q2X\$val")

		ddd<-cbind(bbb,aaa,ccc)

		write.table("",paste(dir,"/R2X_R2Y_Q2X.txt",sep=""),sep="",quote=F,eol="\\t",col.names=FALSE,row.names=FALSE)
		write.table(ddd,paste(dir,"/R2X_R2Y_Q2X.txt",sep=""),sep="\\t",quote=F,append=TRUE)

		#========== splot_1.pdf ===========
		if(file[1]=="pdf"){pdf(paste(dir,"/S_plot.pdf",sep=""),w=9,h=7)}else{jpeg(paste(dir,"/S_plot.jpg",sep=""),width=600,height=480,units="px")}
		ivip<-vip[,1]>=1
		plot(splot[!ivip,1],splot[!ivip,2],col=rgb(0,0,0,50,maxColorValue=255),lwd=0.1,pch=24,cex=0.5,bg="black",xlim=c(min(splot[,1]),max(splot[,1])),ylim=c(-1,1),main="S-plot(VIP>=1)",xlab="w[1]",ylab="p(Corr)")
		points(splot[ivip,1],splot[ivip,2],col=rgb(0,0,0,50,maxColorValue=255),pch=24,cex=1,lwd=0.1,bg="red")
		abline(v=0,col="gray",lty=3)
		abline(h=0,col="gray",lty=3)
		write.table(rownames(vip)[ivip],paste(dir,"/vip_1_mz.txt",sep=""),quote=F,col.names=FALSE,row.names=FALSE)
		dev.off()

		#======================== PC1_PC2.pdf ===================================================
		group_i_j<-group[group==i | group==j]
		group_j<-grep(j,group_i_j)

		if(file[1]=="pdf"){pdf(paste(dir,"/plsda_score_plot.pdf",sep=""),w=9,h=7)}else{jpeg(paste(dir,"/plsda_score_plot.jpg",sep=""),width=600,height=480,units="px")}
		colors<-c("green","blue")
		group_new<-c()
		for(k in 1:length(group_i_j)){group_new[k]<-paste("group",group_i_j[k],sep="");}
		group_new<-as.factor(group_new)
		
		max_pc1<-1.3*(max(abs(s[,1])))
		max_pc2<-1.3*(max(abs(s[,2])))
		lim<-c()
		if(max_pc1 > max_pc2){lim<-c(-max_pc1,max_pc1)}else{lim<-c(-max_pc2,max_pc2)}

		s.class(s[,1:2],group_new,grid=F,pixmap=T,cpoint=1,col=colors,xlim=lim,ylim=lim)
		text(s[,1:2],labels=rownames(rt2)[group==i | group==j],cex=0.4)
		dataEllipse(s[,1],s[,2],levels=c(0.95),add=T,col="gray",lwd=1.4,plot.points=FALSE,center.cex=0.2)
		dev.off()
	}
}
qq

open OT,"|$Rscript - pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

unlink("$outDir_no_QC3/sample_list") if -f "$outDir_no_QC3/sample_list";

#================== 5 Venn_plot =============================================
my $outDir_no_QC5="$outDir/Venn_plot";
mkpath(["$outDir_no_QC5"],0,0755) unless -d "$outDir_no_QC5";

$R_code=<<qq;
library(VennDiagram)

file<-commandArgs(TRUE)
if(length(file)!=1){cat("Usage:\\nRscript xxx.R <picture_type|[pdf|jpg]>\\n");quit()}

#====================================================================
#                QC5_1                   X14_1                   CHD062_1                X9_1                    X12_1
#50.97211673     0.332491667766367       0.597387796066443       0.138011302615631       2.19393320690141        0.0576953971249308
rt<-read.table("$outDir_no_QC3/after_LSC_no_QC.txt",head=T)
rt<-as.matrix(rt)

#====================================================================
#          Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#14_1      1       3       1       108     28      0       0       0
#CHD062_1  1       2       0       36      118     27      16      0.23
rt_sample_list<-read.table("$outDir_no_QC3/sample_list_sort",head=T)
group<-as.numeric(rt_sample_list[,2])

Group<-unique(sort(group))

for(i in 1:(length(Group)-1))
{
	for(j in (i+1):length(Group))
	{
		dir1<-paste("$outDir_no_QC3/",i,"_",j,sep="")
		dir2<-paste("$outDir_no_QC4/PLSDA/",i,"_",j,sep="")
		dir3<-paste("$outDir_no_QC5/",i,"_",j,sep="")
		if(!file_test("-d",dir3)){dir.create(dir3)}

		y<-grep(paste("^",i,"\$|^",j,"\$",sep=""),group)

		volcano_file<-c(paste(dir1,"/volcano_result_ttest.txt",sep=""),paste(dir1,"/volcano_result_wilcox.txt",sep=""))
		vip_file<-c(paste(dir2,"/vip_1_mz.txt",sep=""))
		
		for(m in 1:length(volcano_file))
		{
			rt1<-read.table(volcano_file[m],head=F)
			rt2<-read.table(vip_file[1],head=F)

			aa<-as.vector(rt1[,1])
			bb<-as.vector(rt2[,1])
			
			test_name<-"ttest"
			if(m==2){test_name<-"Wilcoxon"}

			if(file[1]=="pdf"){pdf(paste(dir3,"/Venn_plot_",test_name,".pdf",sep=""),w=10,h=8)}else{jpeg(paste(dir3,"/Venn_plot_",test_name,".jpg",sep=""),width=600,height=480,units="px")}
			venn_plot<-venn.diagram(list(Splot=aa,Volcano=bb),fill=c("red","green"),filename=NULL)
			grid.draw(venn_plot)
			dev.off()

			Venn<-table(c(aa,bb))
			cc<-Venn[Venn>1]
			mz<-rownames(cc)
			write.table(rownames(cc),paste(dir3,"/Venn_plot_",test_name,".txt",sep=""),quote=F,col.names=FALSE,row.names=FALSE)
		}
	}
}
qq

open OT,"|$Rscript - pdf 1>$log 2>&1" or die $!;print OT "$R_code";close OT;
open OT,"|$Rscript - jpg 1>$log 2>&1" or die $!;print OT "$R_code";close OT;

unlink("$outDir_no_QC3/sample_list_sort") if -f "$outDir_no_QC3/sample_list_sort";
unlink("$outDir_no_QC3/after_LSC_no_QC.txt") if -f "$outDir_no_QC3/after_LSC_no_QC.txt";
foreach my $file(glob("$outDir_no_QC4/PLSDA/*/vip_1_mz.txt")){unlink("$file");}

#==================================================================================
#===================== no_QC_report.pl ============================================
#==================================================================================

my $inDir_have_QC=$outDir_have_QC;

%Group=();

#===============================================================
open IN,"<$sample_list" or die $!;
#Sample_Name        Batch   Group   Gender  Age     Ps      Pp      Weight  Pp/Ps
#QC5     1       NA      NA      NA      NA      NA      NA      NA
#14      1       3       F       108     28      NA      NA      NA
while(<IN>)
{
	chomp;
	if($.==1){next;}
	my @r=split /\s+/;
	my ($Sample_Name,$batch,$group)=@r[0,1,2];
	if($Sample_Name=~/^QC/){next;}
	if($batch!~/^\d+$/){next;}
	if($group!~/^\d+$/){next;}

	$Group{$group}=1;
}
close IN;

my @group=sort keys %Group;
my @group_order=();

#====================== html =============================================
mkpath(["$outDir/report/image"],0,0755) unless -d "$outDir/report/image";

copy("$Bin/image/logo.png","$outDir/report/image/logo.png");

foreach my $order(@group_order1)
{
	move("$outDir_have_QC/RSD.$order.jpg","$outDir/report/image/RSD.$order.jpg");
	copy("$outDir_have_QC/RSD.$order.stat","$outDir/report/image/RSD.$order.stat");
}

move("$outDir_have_QC/PCA_score_plot_before_LSC.jpg","$outDir/report/image/PCA_score_plot_before_LSC.jpg");
move("$outDir_have_QC/PCA_score_plot_after_LSC.jpg","$outDir/report/image/PCA_score_plot_after_LSC.jpg");

move("$outDir_have_QC/TIC_before_LSC.jpg","$outDir/report/image/TIC_before_LSC.jpg");
move("$outDir_have_QC/TIC_after_LSC.jpg","$outDir/report/image/TIC_after_LSC.jpg");

move("$outDir_no_QC4/PCA/pca_score_plot.jpg","$outDir/report/image/pca_score_plot.jpg");

foreach my $i(0..($#group-1))
{
	foreach my $j(($i+1)..$#group)
	{
		my $str="$group[$i]_$group[$j]";
		push @group_order,$str;
		move("$outDir_no_QC3/$str/qvalue_t_test_fdr.jpg","$outDir/report/image/$str\_qvalue_t_test_fdr.jpg");
		move("$outDir_no_QC3/$str/qvalue_wilcox_test_fdr.jpg","$outDir/report/image/$str\_qvalue_wilcox_test_fdr.jpg");
		move("$outDir_no_QC3/$str/qvalue_t_test_volcano.jpg","$outDir/report/image/$str\_qvalue_t_test_volcano.jpg");
		move("$outDir_no_QC3/$str/qvalue_wilcox_test_volcano.jpg","$outDir/report/image/$str\_qvalue_wilcox_test_volcano.jpg");
		move("$outDir_no_QC4/PLSDA/$str/plsda_score_plot.jpg","$outDir/report/image/$str\_plsda_score_plot.jpg");
		move("$outDir_no_QC4/PLSDA/$str/S_plot.jpg","$outDir/report/image/$str\_S_plot.jpg");
		move("$outDir_no_QC5/$str/Venn_plot_ttest.jpg","$outDir/report/image/$str\_Venn_plot_ttest.jpg");
		move("$outDir_no_QC5/$str/Venn_plot_Wilcoxon.jpg","$outDir/report/image/$str\_Venn_plot_Wilcoxon.jpg");
	}
}

#============================================================================
my $html="";

$html=<<HTMLCODE;
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=utf-8">
<title>Report of metabonomics in BGI</title>

<style type="text/css">
body {font-family:"Times New Roman"; background-color: #fff; font-size: smaller; margin: 0px 20px; padding-bottom: 20px;}
#logo {background-image: url("./image/logo.png"); background-repeat: no-repeat; height: 100px; padding-left: 190px; padding-top: 60px; color: rgb(0, 85, 153);}
h1 {font-size: 28px; font-weight: 900; padding-top: 10px; border-top: 5px solid #bbf;}
h2 {font-size: 22px; font-weight: 800; border-top: 1px solid #bbf;}
h3 {font-size: 19px; font-weight: 700; border-top: 0px solid #bbf;}
h4 {font-size: 16px; font-weight: 600; border-top: 0px solid #bbf;}
.title {font-size: 22px; font-weight: 900; padding-right: 1em;}
.title2 {font-size: 16px; font-weight: 900; padding-right: 1em;}
p {font-size: 14px; margin-top:5px; margin-bottom:5px;}
img {border:0px; margin:10px 0; width:520px;}
.center {text-align: center;}
tr.head {background-color: rgb(214, 227, 188);}
th, td {font-size: 12px; padding-left:5px;}
.button {padding-right: 1em; padding-left: 1em; display: inline-block; border: 1px solid #000; margin-right: 1em; cursor: pointer; text-align: center; line-height: 1.5em;}
pre {font-size: 20px; padding-left: 2em;}
.h3 {font-size: 20px; font-weight: 900; margin-right: 1em;}
</style>

<style type="text/css" media="print">
h1 {border: 0}
.blank {height: 200px;}
.break {page-break-before: always;}
.button, .it, .forpdf, #pdf_button {display: none;}
a {color: #000; text-decoration: none;}
img {margin: 0;}
table {page-break-inside: avoid;}
</style>

<style type="text/css">
.Black{color:#000;font-weight:bold;font-size:20px}
span.Blacktext{color:#000;font-size:20px}
span.Red{color:Red;font-weight:bold;font-size:small}
</style>

<script type="text/javascript">
function display(mark,total,target)
{
	for(var i=1;i<=total;i++)
	{
		var value=(i==target || target=="all")?"":"none";
		document.getElementById(mark+i).style.display=value;
	}
}

function highlight(mark,total,target)
{
	for(var i=1;i<=total;i++)
	{
		bgColor=(i==target)?"#bbf":"#fff";
		document.getElementById(mark+i).style.backgroundColor=bgColor;
	}
}

function pdfOutput()
{
	window.open("./index.pdf","_blank");
}
</script>

</head>

<body>

<div style="height:120px; background-image:url('./image/logo.png'); background-repeat:no-repeat; border:1px solid white;">
	<div style="margin:55px 0px 0px 180px; font-size:28px; font-weight:900; color:rgb(0,85,153);">
		A Tool for Biomarkers Discovery in Large-Scale Metabolomics
	</div>
</div>

<table><tr>
HTMLCODE

my @titles=("Quality control","Metabolic profiling","Univariate analyses","Volcano plot","Multivariate statistical analyses","Venn plot for potential biomarkers");
my $title_num=@titles;
foreach my $i(0..$#titles+1)
{
	if($i!=0 && $i%8==0){$html.="</tr><tr>";}
	my $j=$i+1;
	if($i<=$#titles){$html.="<td><span id=\"button$j\" class=\"button\" onclick=\"highlight('button',$title_num+1,$j);display('mark',$title_num,$j);\">$titles[$i]</span></td>";}
	if($i==$#titles+1){$html.="<td><span id=\"button$j\" class=\"button\" onclick=\"highlight('button',$title_num+1,$j);display('mark',$title_num,'all');\">Display all</span></td>";}
}
$html.="\n</tr></table>\n\n";

#======================= 1 Quality control ============================================================
$html.=<<HTMLCODE;
<div id="mark1">
<h1 align=left><a name="mark1.0">1 Quality control</a></h1>
<p align=left>
&nbsp;&nbsp;  The RSD values of all peaks were calculated to evaluate the quality of data before and after LOESS signal correction (LSC). According to the quality standard for bio-analytical testing from FDA, the smaller value of Relative Standard Deviation (RSD) the better quality of data. This LSC is fitted to the QC samples, the correction curve interpolated, to which the total data set for that peak is corrected.
</p>

<ul>
<li><a href="#mark1.1">1.1 RSD distribution</a></li>
<li><a href="#mark1.2">1.2 RSD distribution in each category</a></li>
<li><a href="#mark1.3">1.3 Principal component analysis plot for all batches of samples</a></li>
<li><a href="#mark1.4">1.4 Total effective ion chromatogram</a></li>
</ul>

HTMLCODE

#======================= 1.1 RSD distribution ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark1.1">1.1 RSD distribution</h2></a>
<a href="#mark1.0">Back to Top</a>

HTMLCODE

my $figure_num1=0;
my ($tr_num,$td_num)=($#group_order1+1,2);
if(($#group_order1+1)%($td_num)==0){$tr_num=($#group_order1+1)/$td_num;}else{$tr_num=(int(($#group_order1+1)/$td_num))+1;}
if($#group_order1==0){$tr_num=2;$td_num=1;}
my @element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order1[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/RSD.$group_order1[($i/2)*$td_num+$j].jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my $group_str="Group $group_order1[(($i-1)/2)*$td_num+$j]";
			if($group_str eq "Group all"){$group_str="all groups";}
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: $group_str.</span><br />";
		}
	}
}

if($#group_order1==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

#======================= 1.2 RSD distribution in each category, 1-30%, 30%-60% etc ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark1.2">1.2 RSD distribution in each category, 1-30%, 30%-60% etc</h2></a>
<a href="#mark1.0">Back to Top</a>

HTMLCODE

my @stat=();
foreach my $order(@group_order1){push @stat,"$outDir/report/image/RSD.$order.stat";}

my $table_num=1;
if($#group_order1==0){$tr_num=1;$td_num=1;}
my @element3=();
for my $i(0..($tr_num-1))
{
	for my $j(0..($td_num-1))
	{
		last unless $group_order1[$i*$td_num+$j];
		my $group_str="Group $group_order1[$i*$td_num+$j]";
		if($group_str eq "Group all"){$group_str="all groups";}
		$element3[$i][$j]="<table border=1 cellpdding=2 cellspacing=0 bordercolordark=\"black\" align=\"center\"><caption><h3>Table $table_num $group_str.</h3></caption>".&element("$stat[$i*$td_num+$j]")."</table>";
		$table_num=$table_num+1;
	}
}

if($#group_order1==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(1,1,\@element3)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num,$td_num,\@element3)."</table>";
}

#======================= 1.3 Principal component analysis plot for all batches of samples ============================================================
$html.=<<HTMLCODE;


<h2 align=left><a name="mark1.3">1.3 Principal component analysis plot for all batches of samples</a></h2>
<a href="#mark1.0">Back to Top</a>

<p align=left>
&nbsp;&nbsp;  Principal component analysis plot for all batches of samples (PC1 and PC2 were used). Signals shift was observed before LSC correction in the PCA space of data obtained on QC samples and could be robustly corrected by the LSC correction.
</p>

<table align=\"center\">
	<tr align=\"center\">
		<td><img src=\"./image/PCA_score_plot_before_LSC.jpg\" /></td>
		<td><img src=\"./image/PCA_score_plot_after_LSC.jpg\" /></td>
	</tr>
	<tr align=\"center\">
		<td><span class=\"Red\">Figure 1: PCA score plot (before LSC correction)</span></td>
		<td><span class=\"Red\">Figure 2: PCA score plot (after LSC correction)</span></td>
	</tr>
</table>

HTMLCODE

#======================= 1.4 Total effective ion chromatogram ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark1.4">1.4 Total effective ion chromatogram</a></h2>
<a href="#mark1.0">Back to Top</a>

<table align=\"center\">
	<tr align=\"center\">
		<td><img src=\"./image/TIC_before_LSC.jpg\" /></td>
		<td><img src=\"./image/TIC_after_LSC.jpg\" /></td>
	</tr>
	<tr align=\"center\">
		<td><span class=\"Red\">Figure 1: Total ion chromatogram (before LSC correction)</span></td>
		<td><span class=\"Red\">Figure 2: Total ion chromatogram (after LSC correction)</span></td>
	</tr>
</table>

</div>

HTMLCODE

#======================= 2 Metabolic profiling (See the files) ============================================================
$html.=<<HTMLCODE;
<div id="mark2">
<h1 align=left><a name="mark2.0">2 Metabolic profiling (See the files)</a></h1>

<p align=left>
&nbsp;&nbsp; All the peaks with RSD&le;30% will be included. 
</p>

</div>

HTMLCODE

#======================= 3 Univariate analyses ============================================================
$html.=<<HTMLCODE;
<div id="mark3">
<h1 align=left><a name="mark3.0">3 Univariate analyses</a></h1>

<p align=left>
&nbsp;&nbsp;  Density histogram shows the P-value distribution of metabolites. The blue and red curves denote the estimated statistical power and false discovery rate (FDR), respectively, for a particular P-value (Q-value).
</p>

<ul>
<li><a href="#mark3.1">3.1 Welch's t Test and False discovery rate</a></li>
<li><a href="#mark3.2">3.2 Wilcoxon Mann-Whitney test and False discovery rate</a></li>
</ul>

HTMLCODE

#======================= 3.1 Welch's t Test and False discovery rate ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark3.1">3.1 Welch's t Test and False discovery rate</a></h2>
<a href="#mark3.0">Back to Top</a>

HTMLCODE

$figure_num1=0;
if(($#group_order+1)%($td_num)==0){$tr_num=($#group_order+1)/$td_num;}else{$tr_num=(int(($#group_order+1)/$td_num))+1;}
if($#group_order==0){$tr_num=2;$td_num=1;}
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_qvalue_t_test_fdr.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Density histogram of significant value in Group $group_order[(($i-1)/2)*$td_num+$j].</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

#======================= 3.2 Wilcoxon Mann-Whitney test and False discovery rate ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark3.2">3.2 Wilcoxon Mann-Whitney test and False discovery rate</a></h2>
<a href="#mark3.0">Back to Top</a>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_qvalue_wilcox_test_fdr.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Density histogram of significant value in Group $group_order[(($i-1)/2)*$td_num+$j].</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

$html.="\n</div>\n\n";

#======================= 4 Volcano plot ============================================================
$html.=<<HTMLCODE;
<div id="mark4">
<h1 align=left><a name="mark4.0">4 Volcano plot</a></h1>

<p align=left>
&nbsp;&nbsp;  The volcano plot is a type of scatter-plot that is used to quickly identify changes in large datasets composed of replicate data. It plots significance versus fold-change on the x-axes and Q-value on the y-axes, respectively.
</p>

<ul>
<li><a href="#mark4.1">4.1 Volcano plot for Welch's t Test</a></li>
<li><a href="#mark4.2">4.2 Volcano plot for Wilcoxon Mann-Whitney test</a></li>
</ul>

HTMLCODE

#======================= 4.1 Volcano plot for Welch's t Test ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark4.1">4.1 Volcano plot for Welch's t Test</a></h2>
<a href="#mark4.0">Back to Top</a>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_qvalue_t_test_volcano.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my ($gp1,$gp2)=($1,$2) if $group_order[(($i-1)/2)*$td_num+$j]=~/^(\d+)_(\d+)$/;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Volcano plot (Group $gp1 vs $gp2, Welch's t Test).</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

#======================= 4.2 Volcano plot for Wilcoxon Mann-Whitney test ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark4.2">4.2 Volcano plot for Wilcoxon Mann-Whitney test</a></h2>
<a href="#mark4.0">Back to Top</a>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_qvalue_wilcox_test_volcano.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my ($gp1,$gp2)=($1,$2) if $group_order[(($i-1)/2)*$td_num+$j]=~/^(\d+)_(\d+)$/;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Volcano plot (Group $gp1 vs $gp2, Wilcoxon Mann-Whitney test).</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

$html.="\n</div>\n\n";

#======================= 5 Multivariate statistical analyses ============================================================
$html.=<<HTMLCODE;
<div id="mark5">
<h1 align=left><a name="mark5.0">5 Multivariate statistical analyses</a></h1>

<ul>
<li><a href="#mark5.1">5.1 Principal component analysis (PCA)</a></li>
<li><a href="#mark5.2">5.2 Partial least squares-discriminate analysis (PLS-DA)</a></li>
<li><a href="#mark5.2.1">5.2.1 PLS-DA score plot</a></li>
<li><a href="#mark5.2.2">5.2.2 PLS-DA S-plot</a></li>
</ul>

HTMLCODE

#======================= 5.1 Principal component analysis (PCA) ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark5.1">5.1 Principal component analysis (PCA)</a></h2>
<a href="#mark5.0">Back to Top</a>

<p align=left>
&nbsp;&nbsp;  PCA score plot for all samples. PC1 and PC2 were used. With a two dimensional score plot, metaboBD draws the tolerance ellipse based on the Hotelling T2 (0.05). The outliers are the observations situated outside the ellipse.
</p>

<table align=\"center\">
	<tr align=\"center\">
		<td><img style=\"width:520px;\" src=\"./image/pca_score_plot.jpg\" /></td>
	</tr>
	<tr align=\"center\">
		<td><span class=\"Red\">Figure: PCA score plot.</span></td>
	</tr>
</table>

HTMLCODE

#======================= 5.2 Partial least squares-discriminate analysis (PLS-DA) ============================================================
$html.=<<HTMLCODE;
<h2 align=left><a name="mark5.2">5.2 Partial least squares-discriminate analysis (PLS-DA)</a></h2>

HTMLCODE

#======================= 5.2.1 PLS-DA score plot ============================================================
$html.=<<HTMLCODE;
<h3 align=left><a name="mark5.2.1">5.2.1 PLS-DA score plot</a></h3>
<a href="#mark5.0">Back to Top</a>

<p align=left>
&nbsp;&nbsp;  PLS-DA score plot for the samples between two groups. With a two dimensional score plot, metaboBD draws the tolerance ellipse based on the Hotelling T2 (0.05). The outliers are the observations situated outside the ellipse.
</p>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_plsda_score_plot.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Group $group_order[(($i-1)/2)*$td_num+$j] PLS-DA score plot.</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

#======================= 5.2.2 PLS-DA S-plot ============================================================
$html.=<<HTMLCODE;
<h3 align=left><a name="mark5.2.2">5.2.2 PLS-DA S-plot</a></h3>
<a href="#mark5.0">Back to Top</a>

<p align=left>
&nbsp;&nbsp;  S-plot, proposed as a tool for visualization and interpretation of multivariate classification models, considers the covariance and correlation between the metabolites and the modeled class designation on the x-axes and on the y-axes, respectively.
</p>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img src=\"./image/$group_order[($i/2)*$td_num+$j]\_S_plot.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my ($gp1,$gp2)=($1,$2) if $group_order[(($i-1)/2)*$td_num+$j]=~/^(\d+)_(\d+)$/;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: S-plot (Groups $gp1 vs $gp2, w[1] indicated the covariance and p[Corr] indicated the correlation).</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

$html.="\n</div>\n\n";

#======================= 6 Venn plot for potential biomarkers ============================================================
$html.=<<HTMLCODE;
<div id="mark6">
<h1 align=left><a name="mark6.0">6 Venn plot for potential biomarkers</a></h1>

<p align=left>
&nbsp;&nbsp;  Potential biomarkers will be selected by combining results of volcano plot and VIP value in PLSDA model.
</p>

<ul>
<li><a href="#mark6.1.1">Venn_plot_ttest</a></li>
<li><a href="#mark6.1.2">Venn_plot_Wilcoxon</a></li>
</ul>

HTMLCODE

#======================= 6.1.1 volcano_splot_venn_1_2.jpg ============================================================
$html.=<<HTMLCODE;

<h3 align=left><a name="mark6.1.1">Venn_plot_ttest</a></h3>
<a href="#mark6.0">Back to Top</a>

HTMLCODE
$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img style=\"width:520px;\" src=\"./image/$group_order[($i/2)*$td_num+$j]\_Venn_plot_ttest.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my ($gp1,$gp2)=($1,$2) if $group_order[(($i-1)/2)*$td_num+$j]=~/^(\d+)_(\d+)$/;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Venn plot (Groups $gp1 vs $gp2, Q-value &le;0.05 & fold change &ge;1.2 or &le;0.8 & VIP &ge;1)).</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

#======================= 6.1.2 volcano_splot_venn_1_2.jpg ============================================================
$html.=<<HTMLCODE;

<h3 align=left><a name="mark6.1.2">Venn_plot_Wilcoxon</a></h3>
<a href="#mark6.0">Back to Top</a>

HTMLCODE

$figure_num1=0;
@element1=();
for my $i(0..($tr_num*2-1))
{
	for my $j(0..($td_num-1))
	{
		if($i%2==0)
		{
			if(!exists $group_order[($i/2)*$td_num+$j]){$element1[$i][$j]="";next;}
			$element1[$i][$j]="<img style=\"width:520px;\" src=\"./image/$group_order[($i/2)*$td_num+$j]\_Venn_plot_Wilcoxon.jpg\" />";
		}else
		{
			if($element1[$i-1][$j] eq ""){last;}
			$figure_num1++;
			my ($gp1,$gp2)=($1,$2) if $group_order[(($i-1)/2)*$td_num+$j]=~/^(\d+)_(\d+)$/;
			$element1[$i][$j]="<span class=\"Red\">Figure $figure_num1: Venn plot (Groups $gp1 vs $gp2, Q-value &le;0.05 & fold change &ge;1.2 or &le;0.8 & VIP &ge;1)).</span><br />";
		}
	}
}

if($#group_order==0)
{
	$html.="<table align=\"center\" cellspacing=10>".&Table(2,1,\@element1)."</table>";
}else
{
	$html.="<table align=\"center\" cellspacing=10>".&Table($tr_num*2,$td_num,\@element1)."</table>";
}

$html.="\n</div>\n\n";

#==================== END =========================================================
$html.=<<HTMLCODE;

<table width="900" border="0">
<tr>
	<td style="text-indent:600px;font-size:20px;" align="right">&nbsp;Project: $Project</td>
</tr>
<tr>
	<td style="text-indent:600px;font-size:20px;" align="right">&nbsp;Date: $year-$mon-$mday</td>
</tr>
</table>

</body>
</html>
HTMLCODE

my $html_file="$outDir/report/$Project\_report.html";
open OT,">$html_file" or die $!;
print OT "$html";
close OT;

print "--- $html_file\n";

($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
$year=$year+1900;
$mon=$mon+1;

print "end: $year-$mon-$mday: $hour:$min:$sec\n";

##========== sub Table ===============================================
sub Table
{
	my ($tr_num,$td_num,$arry)=@_[0,1,2];
	my ($str,@arry)=("",@$arry);
	map {my $i=$_-1;$str.="<tr align=\"center\">";map {my $j=$_-1;$arry[$i][$j]||="";$str.="<td><span style=\"width:520px;display:block;\">$arry[$i][$j]</span></td>";} 1..$td_num;$str.="</tr>";} 1..$tr_num;
	return $str;
}
#========== sub element ==================
sub element
{
	my $stat=$_[0];
	my $str="";
	open ST,"<$stat" or die $!;
	while(<ST>)
	{
		chomp;
		my @r=split /\t/;
		if($.==1)
		{
			$str.="<tr class=\"head\">";
			map {my $i=$_;$str.="<th>$r[$i]</th>";} 0..$#r;
		}else
		{
			$str.="<tr>";
			map {my $i=$_;$str.="<td>$r[$i]</td>";} 0..$#r;
		}
		$str.="</tr>";
	}
	close ST;
	return $str;
}
